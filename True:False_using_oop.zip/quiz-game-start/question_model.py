class Question:
    def __init__(self,text,ans):
        self.text=text
        self.ans=ans


